<?php 

    $con = mysqli_connect('localhost','id19977691_lovejoysecurityadmin','Simarkhanijou12!','id19977691_lovejoysecurity');
    if(!$con)
    {
        echo 'Not Connected ';
    }
  

?>