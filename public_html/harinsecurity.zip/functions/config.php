<?php 

    ob_start();
    session_start();
    require_once('function.php');
    require_once('db.php');


?>