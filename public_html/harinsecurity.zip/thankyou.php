<?php require_once('includes/header.php') ?>
    
    


        <!---Navigation Bar-->
        <?php require_once('includes/nav.php'); ?>
        <?php display_message(); ?>
        <!--Main Page Content-->
        <div class="container">
            <div class="card mt-5">
                <div class="card-title">
                    <div class="card-body">
                        <h2 class="text-center"> Thank you for your submission</h2>
                        <h4 class="text-center"> The admin will contact you soon</h4>
                    </div>
                </div>
            </div>
        </div>


<?php require_once('includes/footer.php') ?>        

